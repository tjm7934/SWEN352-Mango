package com.serotonin.mango.vo.hierarchy;

public interface PointHierarchyListener {
    void pointHierarchySaved(PointFolder root);
}
